const express = require('express');
const app = express();

// Add the favicon route handler early before other routes
app.get('/favicon.ico', (req, res) => res.status(204).end());

// Other route handlers
app.get('/', (req, res) => {
  res.send('Homepage');
});

// Start server
app.listen(3001, () => {
  console.log('Server running on port 3001');
});
